#ifndef WC_WC_HELPERS_SINGLE_H
#define WC_WC_HELPERS_SINGLE_H

/*
 * wc_helpers_single.h
 * Auto-generated single-header library.
 *
 * In EXACTLY ONE .c file, before including this header:
 *     #define WC_IMPLEMENTATION
 *     #include "wc_helpers_single.h"
 *
 * All other files just:
 *     #include "wc_helpers_single.h"
 */

/* ===== common.h ===== */
#ifndef WC_COMMON_H
#define WC_COMMON_H

/*
 * WCtoolkit
 * Copyright (c) 2026 Wasi Ullah (PAKIWASI)
 * Licensed under the MIT License. See LICENSE file for details.
 */



// LOGGING/ERRORS

#include <stdio.h>
#include <stdlib.h>

// ANSI Color Codes
#define WC_COLOR_RESET  "\033[0m"
#define WC_COLOR_RED    "\033[1;31m"
#define WC_COLOR_YELLOW "\033[1;33m"
#define WC_COLOR_GREEN  "\033[1;32m"
#define WC_COLOR_BLUE   "\033[1;34m"
#define WC_COLOR_CYAN   "\033[1;36m"



// TODO: warm paths ?

#define WARN(fmt, ...)                                            \
    do {                                                          \
        printf(WC_COLOR_YELLOW "[WARN]"                              \
                            " %s:%d:%s(): " fmt "\n" WC_COLOR_RESET, \
               __FILE__, __LINE__, __func__, ##__VA_ARGS__);      \
    } while (0)

#define FATAL(fmt, ...)                                         \
    do {                                                        \
        fprintf(stderr,                                         \
                WC_COLOR_RED "[FATAL]"                             \
                          " %s:%d:%s(): " fmt "\n" WC_COLOR_RESET, \
                __FILE__, __LINE__, __func__, ##__VA_ARGS__);   \
        exit(EXIT_FAILURE);                                     \
    } while (0)

#define CHECK_WARN(cond, fmt, ...)                           \
    do {                                                     \
        if (__builtin_expect(!!(cond), 0)) {                 \
            WARN("Check: (%s): " fmt, #cond, ##__VA_ARGS__); \
        }                                                    \
    } while (0)

#define CHECK_WARN_RET(cond, ret, fmt, ...)                  \
    do {                                                     \
        if (__builtin_expect(!!(cond), 0)) {                 \
            WARN("Check: (%s): " fmt, #cond, ##__VA_ARGS__); \
            return ret;                                      \
        }                                                    \
    } while (0)

#define CHECK_FATAL(cond, fmt, ...)                           \
    do {                                                      \
        if (__builtin_expect(!!(cond), 0)) {                  \
            FATAL("Check: (%s): " fmt, #cond, ##__VA_ARGS__); \
        }                                                     \
    } while (0)

#define LOG(fmt, ...)                                       \
    do {                                                    \
        printf(WC_COLOR_CYAN "[LOG]"                           \
                          " : %s(): " fmt "\n" WC_COLOR_RESET, \
               __func__, ##__VA_ARGS__);                    \
    } while (0)


#define MALLOC(size, cap, name) ({\
    void* _mlcd = malloc(size * cap);\
    CHECK_FATAL(!_mlcd, "\"" #name "\"" " malloc failed");\
    _mlcd;\
})


// TYPES

#include <stdint.h>
#include <stdbool.h>

typedef uint8_t  u8;
typedef uint8_t  b8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

// #define false ((b8)0)
// #define true  ((b8)1)


// GENERIC FUNCTIONS
typedef void (*copy_fn)(u8* dest, const u8* src);
typedef void (*move_fn)(u8* dest, u8** src);
typedef void (*delete_fn)(u8* key);
typedef void (*print_fn)(const u8* elm);
typedef int (*compare_fn)(const u8* a, const u8* b, u64 size);


// Vtable: one instance shared across all vectors of the same type.
// Pass NULL for any callback not needed.
// For POD types, pass NULL for the whole ops pointer.
typedef struct {
    copy_fn   copy_fn; // Deep copy function for owned resources (or NULL)
    move_fn   move_fn; // Transfer ownership and null original (or NULL)
    delete_fn del_fn;  // Cleanup function for owned resources (or NULL)
} container_ops;


// CASTING

#define cast(x)    ((u8*)(&(x)))
#define castptr(x) ((u8*)(x))


// COMMON SIZES

#define KB (1 << 10)
#define MB (1 << 20)

#define nKB(n) ((u64)((n) * KB))
#define nMB(n) ((u64)((n) * MB))


// RAW BYTES TO HEX

static inline void print_hex(const u8* ptr, u64 size, u32 bytes_per_line)
{
    if (ptr == NULL || size == 0 || bytes_per_line == 0) {
        return;
    }

    // hex rep 0-15
    const char* hex = "0123456789ABCDEF";

    for (u64 i = 0; i < size; i++) {
        u8 val1 = ptr[i] >> 4;   // get upper 4 bits as num b/w 0-15
        u8 val2 = ptr[i] & 0x0F; // get lower 4 bits as num b/w 0-15

        printf("%c%c", hex[val1], hex[val2]);

        // Add space or newline appropriately
        if ((i + 1) % bytes_per_line == 0) {
            printf("\n");
        } else if (i < size - 1) {
            printf(" ");
        }
    }

    // Add final newline if we didn't just print one
    if (size % bytes_per_line != 0) {
        printf("\n");
    }
}


// TEST HELPERS

// Generic print functions for primitive types
static inline void wc_print_int(const u8* elm)
{
    printf("%d ", *(int*)elm);
}
static inline void wc_print_u32(const u8* elm)
{
    printf("%u ", *(u32*)elm);
}
static inline void wc_print_u64(const u8* elm)
{
    printf("%llu ", (unsigned long long)*(u64*)elm);
}
static inline void wc_print_float(const u8* elm)
{
    printf("%.2f ", *(float*)elm);
}
static inline void wc_print_char(const u8* elm)
{
    printf("%c ", *(char*)elm);
}
static inline void wc_print_cstr(const u8* elm)
{
    printf("%s ", (const char*)elm);
}

#endif /* WC_COMMON_H */

/* ===== wc_errno.h ===== */
#ifndef WC_WC_ERRNO_H
#define WC_WC_ERRNO_H

#include <stdio.h>


/* wc_errno.h — Error reporting for WCtoolkit
 * ============================================
 *
 * Two tiers:
 *
 *   CHECK_FATAL  Programmer errors: null pointer, out of bounds, OOM.
 *                Crashes with a message. These are bugs, not conditions.
 *
 *   wc_errno     Expected conditions: pop on empty, arena full.
 *                Function returns NULL / 0 / void. wc_errno says why.
 *                Ignore it if you don't care. Check it if you do.
 *
 *
 * USAGE
 * -----
 *   // Check a single call:
 *   wc_errno = WC_OK;
 *   u8* p = arena_alloc(arena, size);
 *   if (!p && wc_errno == WC_ERR_FULL) { ... }
 *
 *   // Check a batch — wc_errno stays set if any call failed:
 *   wc_errno = WC_OK;
 *   float* a = (float*)arena_alloc(arena, 256);
 *   float* b = (float*)arena_alloc(arena, 256);
 *   if (wc_errno) { wc_perror("alloc"); }
 *
 *
 * RULES
 * -----
 *   1. Successful calls do NOT clear wc_errno — clear it yourself.
 *   2. Check the return value first. wc_errno tells you WHY, not WHETHER.
 *   3. wc_errno is thread-local. Each thread has its own copy.
 *
 *
 * WHAT SETS wc_errno
 * ------------------
 *   arena_alloc, arena_alloc_aligned      WC_ERR_FULL    arena exhausted
 *   genVec_pop, genVec_front, genVec_back WC_ERR_EMPTY   vec is empty
 *   dequeue, queue_peek, queue_peek_ptr   WC_ERR_EMPTY   queue is empty
 *   stack_pop, stack_peek                 WC_ERR_EMPTY   stack is empty
 */


typedef enum {
    WC_OK        = 0,
    WC_ERR_FULL,       // arena exhausted / container at capacity
    WC_ERR_EMPTY,      // pop or peek on empty container
    WC_ERR_INVALID_OP, // call to a function with preconditions not met
} wc_err;

static inline const char* wc_strerror(wc_err e)
{
    switch (e) {
        case WC_OK:             return "ok";
        case WC_ERR_FULL:       return "full";
        case WC_ERR_EMPTY:      return "empty";
        case WC_ERR_INVALID_OP: return "invalid op";
        default:                return "unknown";
    }
}

/* Defined in wc_errno.c:
 *   _Thread_local wc_err wc_errno = WC_OK;
 */
extern _Thread_local wc_err wc_errno;

/* Print last error — same pattern as perror(3).
 *   wc_perror("arena_alloc");  ->  "arena_alloc: full"
 */
static inline void wc_perror(const char* prefix)
{
    if (prefix && prefix[0]) {
        fprintf(stderr, "%s: %s\n", prefix, wc_strerror(wc_errno));
    } else {
        fprintf(stderr, "%s\n", wc_strerror(wc_errno));
    }
}


/* Internal macros (library use only)
 * ------------------------------------
 * WC_SET_RET — replaces CHECK_WARN_RET at expected-condition sites.
 * Sets wc_errno silently and returns. No print.
 *
 *   WC_SET_RET(WC_ERR_EMPTY, vec->size == 0, );     void return
 *   WC_SET_RET(WC_ERR_FULL,  cond,           NULL); pointer return
 */
#define WC_SET_RET(err_code, cond, ret) \
    do {                                \
        if (cond) {                     \
            wc_errno = (err_code);      \
            return ret;                 \
        }                               \
    } while (0)

/* WC_PROPAGATE_RET — exit immediately if a callee already set wc_errno.
 *
 *   some_internal_fn(vec);
 *   WC_PROPAGATE_RET( );   // exits if some_internal_fn set wc_errno
 */
#define WC_PROPAGATE_RET(ret)    \
    do {                         \
        if (wc_errno != WC_OK) { \
            return ret;          \
        }                        \
    } while (0)

#endif /* WC_WC_ERRNO_H */

/* ===== String.h ===== */
#ifndef WC_STRING_H
#define WC_STRING_H

#ifndef STRING_GROWTH
    #define STRING_GROWTH    1.5F    // capacity multiplier on grow
#endif

#define STR_SSO_SIZE 24


typedef struct {
    union {
        char* heap;
        char  stk[STR_SSO_SIZE];
    };
    // b8  sso;     // if cap is = STR_SSO_SIZE then we are in sso mode, if greater then heap mode
    u64 size;
    u64 capacity;
} String;

// 24 8 8 = 40 bytes (same as genVec)


//  Construction / Destruction 

// Create an empty string on the heap.
String* string_create(void);

// Create a string on the heap from a cstr.
String* string_from_cstr(const char* cstr);

// Create a copy of another heap-allocated string.
String* string_from_string(const String* other);

// Initialise a String whose struct lives on the stack (data may be on heap).
void string_create_stk(String* str, const char* cstr);

// Destroy a heap-allocated String (frees struct + data).
void string_destroy(String* str);

// Destroy only the internal data of a stack-allocated String.
void string_destroy_stk(String* str);

// Move: transfer ownership from *src to dest, nulling *src.
// *src must be heap-allocated.
void string_move(String* dest, String** src);

// Deep copy src into dest (dest is re-initialised).
void string_copy(String* dest, const String* src);


//  Capacity 

// Ensure capacity >= new_cap (never shrinks).
void string_reserve(String* str, u64 new_cap);

// Reserve capacity and fill new slots with c.
void string_reserve_char(String* str, u64 new_cap, char c);

// Shrink allocation to exactly fit current size.
void string_shrink_to_fit(String* str);


//  Conversion 

// Return a malloc'd NUL-terminated copy — caller must free().
char* string_to_cstr(const String* str);

void string_to_cstr_buf(const String* str, char* buff, u64 n);

// Return a raw pointer into the internal buffer (no NUL terminator).
char* string_data_ptr(const String* str);


//  Modification 

void string_append_char(String* str, char c);
void string_append_cstr(String* str, const char* cstr);
void string_append_string(String* str, const String* other);
// Append other then destroy it (nulls *other).
void string_append_string_move(String* str, String** other);

char string_pop_char(String* str);

void string_insert_char(String* str, u64 i, char c);
void string_insert_cstr(String* str, u64 i, const char* cstr);
void string_insert_string(String* str, u64 i, const String* other);

void string_remove_char(String* str, u64 i);

// TODO: test
// Remove chars in range [start, start + len)
void string_remove_range(String* str, u64 start, u64 len);

// Remove all chars (keep allocation).
void string_clear(String* str);


//  Access 

char string_char_at(const String* str, u64 i);
void string_set_char(String* str, u64 i, char c);


//  Comparison 

// 0 == equal, <0 == str1 < str2, >0 == str1 > str2
int string_compare(const String* s1, const String* s2);
b8  string_equals(const String* s1, const String* s2);
b8  string_equals_cstr(const String* str, const char* cstr);


//  Search 

// Returns index, or (u64)-1 if not found.
u64 string_find_char(const String* str, char c);
u64 string_find_cstr(const String* str, const char* substr);

// Return a heap-allocated substring starting at `start` of `length` chars.
String* string_substr(const String* str, u64 start, u64 length);


//  I/O 

void string_print(const String* str);


//  Inline helpers 

static inline u64 string_len(const String* str)
{
    CHECK_FATAL(!str, "str is null");
    return str->size;
}

static inline u64 string_capacity(const String* str)
{
    CHECK_FATAL(!str, "str is null");
    return str->capacity;
}

static inline b8 string_empty(const String* str)
{
    CHECK_FATAL(!str, "str is null");
    return str->size == 0;
}

static inline b8 string_sso(const String* str)
{
    CHECK_FATAL(!str, "str is null");
    return str->capacity == STR_SSO_SIZE;
}


/*
 Macro to temporarily NUL-terminate a String for read-only C APIs.
Note: Do NOT break/return/goto inside the block.

 Usage:
   TEMP_CSTR_READ(s) {
       printf("%s\n", string_data_ptr(s));
   }
*/
#define TEMP_CSTR_READ(str) \
    for (u8 _once = 0; \
         (_once == 0) && (string_append_char((str), '\0'), 1); \
         _once++, string_pop_char((str)))

#endif /* WC_STRING_H */

/* ===== wc_helpers.h ===== */
#ifndef WC_WC_HELPERS_H
#define WC_WC_HELPERS_H

/*
 * wc_helpers.h — Generic container callbacks and typed macros for WCtoolkit
 * =======================================================================
 *
 * ALL functions are static inline to avoid multiple-definition linker
 * errors when this header is included in more than one translation unit.
 *
 * SECTIONS
 * --------
 *   1.  String by value  (sizeof(String) per slot)
 *   2.  String by pointer (sizeof(String*) per slot)
 *   3.  genVec by value  (sizeof(genVec) per slot)  — vec of vecs
 *   4.  genVec by pointer (sizeof(genVec*) per slot)
 *   5.  Shared ops instances (define once, reference everywhere)
 *
 * RULES FOR WRITING copy/move/del CALLBACKS
 * ------------------------------------------
 *
 * BY VALUE  (slot holds the full struct, sizeof(T) bytes)
 *   copy_fn(u8* dest, const u8* src)
 *     dest  — raw bytes of the slot (uninitialised — treat as blank)
 *     src   — raw bytes of the source element
 *     job   — deep-copy all owned resources into dest; DO NOT free dest first.
 *             If delegating to a function that calls destroy internally (e.g.
 *             string_copy), you MUST first init dest to a valid empty state.
 *
 *   move_fn(u8* dest, u8** src)
 *     dest  — raw bytes of the slot (uninitialised)
 *     *src  — heap pointer to the source T
 *     job   — memcpy the struct fields, free(*src), *src = NULL
 *             The data ptr moves; only the container struct is freed.
 *
 *   del_fn(u8* elm)
 *     elm   — raw bytes of the slot
 *     job   — free owned resources (e.g. data buffer) but NOT elm itself
 *             → call string_destroy_stk / genVec_destroy_stk etc.
 *
 * BY POINTER  (slot holds T*, sizeof(T*) = 8 bytes)
 *   copy_fn(u8* dest, const u8* src)
 *     *(T**)src  is the source pointer
 *     *(T**)dest must be set to a newly heap-allocated deep copy
 *
 *   move_fn(u8* dest, u8** src)
 *     *(T**)dest = *(T**)src;  *src = NULL;
 *
 *   del_fn(u8* elm)
 *     *(T**)elm  is the pointer stored in the slot
 *     job — fully destroy the heap object
 *           → call string_destroy / genVec_destroy etc.
 */

#include <string.h>


/* ══════════════════════════════════════════════════════════════════════════
 * 1.  STRING BY VALUE
 *
 * String is SSO-based (no data_size / data fields).
 * str_copy  — delegates to string_copy()  (handles SSO vs heap correctly)
 * str_move  — memcpy the struct shell, free the source container
 * str_del   — delegates to string_destroy_stk() (frees heap buf if any)
 * ══════════════════════════════════════════════════════════════════════════ */

static inline void str_copy(u8* dest, const u8* src)
{
    // dest is uninitialised raw slot memory — init to valid SSO state first
    // so that string_copy's internal string_destroy_stk(dest) is safe.
    String* d = (String*)dest;
    // d->size     = 0;
    // d->capacity = STR_SSO_SIZE;
    // string_copy(d, (const String*)src);

    String* s = (String*)src;
    memcpy(d, s, sizeof(String));

    if (s->capacity == STR_SSO_SIZE) {
        return; // str stored inline, we have everything 
    }

    // src owns resources, copy them
    d->heap = malloc(s->capacity);
    memcpy(d->heap, s->heap, s->capacity);
}

static inline void str_move(u8* dest, u8** src)
{
    // *src is a heap-allocated String* — move its contents into the slot,
    // then free the shell. Works for both SSO (copies stk[]) and heap mode.
    memcpy(dest, *src, sizeof(String));
    free(*src);
    *src = NULL;
}

static inline void str_del(u8* elm)
{
    string_destroy_stk((String*)elm);   // free data buffer, NOT the slot
}

static inline void str_print(const u8* elm)
{
    string_print((const String*)elm);
}


/* ══════════════════════════════════════════════════════════════════════════
 * 2.  STRING BY POINTER
 *
 * str_copy_ptr — delegates to string_from_string() for a full heap copy
 * str_move_ptr — pointer swap, nulls source
 * str_del_ptr  — delegates to string_destroy() (frees buf + struct)
 * ══════════════════════════════════════════════════════════════════════════ */

static inline void str_copy_ptr(u8* dest, const u8* src)
{
    *(String**)dest = string_from_string(*(const String**)src);
}

static inline void str_move_ptr(u8* dest, u8** src)
{
    *(String**)dest = *(String**)src;
    *src            = NULL;
}

static inline void str_del_ptr(u8* elm)
{
    string_destroy(*(String**)elm);
}

static inline void str_print_ptr(const u8* elm)
{
    string_print(*(const String**)elm);
}

static inline int str_cmp(const u8* a, const u8* b, u64 size)
{
    (void)size;
    return string_compare((const String*)a, (const String*)b);
}

static inline int str_cmp_ptr(const u8* a, const u8* b, u64 size)
{
    (void)size;
    return string_compare(*(const String**)a, *(const String**)b);
}


/* ══════════════════════════════════════════════════════════════════════════
 * 3.  GENVEC BY VALUE  (vec of vecs)
 * ══════════════════════════════════════════════════════════════════════════ */

static inline void vec_copy(u8* dest, const u8* src)
{
    const genVec* s = (const genVec*)src;
    genVec*       d = (genVec*)dest;

    memcpy(d, s, sizeof(genVec));                           // copy all fields (including ops ptr)
    d->data = malloc(s->capacity * (u64)s->data_size);      // new data buffer

    copy_fn copy = VEC_COPY_FN(s);                          // safe: handles NULL ops
    if (copy) {
        for (u64 i = 0; i < s->size; i++) {
            copy(d->data + (i * d->data_size), genVec_get_ptr(s, i));
        }
    } else {
        memcpy(d->data, s->data, s->capacity * (u64)s->data_size);
    }
}

static inline void vec_move(u8* dest, u8** src)
{
    memcpy(dest, *src, sizeof(genVec));  // transfer all fields (incl. data ptr and ops ptr)
    free(*src);                          // free container struct only
    *src = NULL;
}

static inline void vec_del(u8* elm)
{
    genVec_destroy_stk((genVec*)elm);    // free data buffer, NOT the slot
}

static inline void vec_print_int(const u8* elm)
{
    const genVec* v = (const genVec*)elm;
    printf("[");
    for (u64 i = 0; i < v->size; i++) {
        printf("%d", *(int*)genVec_get_ptr(v, i));
        if (i + 1 < v->size) { printf(", "); }
    }
    printf("]");
}


/* ══════════════════════════════════════════════════════════════════════════
 * 4.  GENVEC BY POINTER  (slot holds genVec*)
 * ══════════════════════════════════════════════════════════════════════════ */

static inline void vec_copy_ptr(u8* dest, const u8* src)
{
    const genVec* s = *(const genVec**)src;

    genVec* d = malloc(sizeof(genVec));
    memcpy(d, s, sizeof(genVec));                           // copies ops ptr too
    d->data   = malloc(s->capacity * (u64)s->data_size);

    copy_fn copy = VEC_COPY_FN(s);
    if (copy) {
        for (u64 i = 0; i < s->size; i++) {
            copy(d->data + (i * d->data_size), genVec_get_ptr(s, i));
        }
    } else {
        memcpy(d->data, s->data, s->capacity * (u64)s->data_size);
    }

    *(genVec**)dest = d;
}

static inline void vec_move_ptr(u8* dest, u8** src)
{
    *(genVec**)dest = *(genVec**)src;
    *src            = NULL;
}

static inline void vec_del_ptr(u8* elm)
{
    genVec_destroy(*(genVec**)elm);
}

static inline void vec_print_int_ptr(const u8* elm)
{
    vec_print_int((const u8*)*(const genVec**)elm);
}


/* ══════════════════════════════════════════════════════════════════════════
 * 5.  SHARED OPS INSTANCES
 *
 * Define once here as static const. Reference by address wherever needed.
 * No per-instance overhead — all vectors of the same type share the pointer.
 *
 * Usage:
 *   genVec* v = genVec_init(8, sizeof(String), &wc_str_ops);
 *   hashmap* m = hashmap_create(..., &wc_str_ops, &wc_str_ops);
 * ══════════════════════════════════════════════════════════════════════════ */

static const container_ops wc_str_ops     = { str_copy,     str_move,     str_del     };
static const container_ops wc_str_ptr_ops = { str_copy_ptr, str_move_ptr, str_del_ptr };
static const container_ops wc_vec_ops     = { vec_copy,     vec_move,     vec_del     };
static const container_ops wc_vec_ptr_ops = { vec_copy_ptr, vec_move_ptr, vec_del_ptr };

#endif /* WC_WC_HELPERS_H */

#ifdef WC_IMPLEMENTATION

/* ===== wc_errno.c ===== */
#ifndef WC_WC_ERRNO_IMPL
#define WC_WC_ERRNO_IMPL

/* One definition of the thread-local error variable.
 * Every translation unit that includes wc_error.h sees the extern declaration.
 * This file provides the actual storage.
 */
_Thread_local wc_err wc_errno = WC_OK;

#endif /* WC_WC_ERRNO_IMPL */

/* ===== String.c ===== */
#ifndef WC_STRING_IMPL
#define WC_STRING_IMPL

#include <string.h>


//  Internal macros

#define IS_SSO(s)          ((s)->capacity == STR_SSO_SIZE)
#define GET_STR(s)         (IS_SSO(s) ? (s)->stk : (s)->heap)
#define GET_STR_PTR(s, i)  (GET_STR(s) + i)
#define GET_STR_CHAR(s, i) (GET_STR(s)[i])
#define STR_REMAINING(s)   ((s)->capacity - (s)->size)

// Grow if full.
#define MAYBE_GROW_STR(s)                     \
    do {                                  \
        if ((s)->size >= (s)->capacity) { \
            if (IS_SSO(s)) {              \
                stk_to_heap(s);           \
            } else {                      \
                string_grow(s);           \
            }                             \
        }                                 \
    } while (0)



//  Private helpers

static u64  cstr_len(const char* cstr);
static void str_copy_n(char* dest, const char* src, u64 n);
static void stk_to_heap(String* s);
static void heap_to_stk(String* s);
static void string_grow(String* s);
static void ensure_capacity(String* s, u64 needed);



//  Construction / Destruction

String* string_create(void)
{
    String* s = malloc(sizeof(String));
    CHECK_FATAL(!s, "malloc failed");

    s->size     = 0;
    s->capacity = STR_SSO_SIZE;

    return s;
}

String* string_from_cstr(const char* cstr)
{
    String* s = malloc(sizeof(String));
    CHECK_FATAL(!s, "malloc failed");

    string_create_stk(s, cstr);
    return s;
}

String* string_from_string(const String* other)
{
    CHECK_FATAL(!other, "other is null");

    String* s = malloc(sizeof(String));
    CHECK_FATAL(!s, "malloc failed");

    s->size     = 0;
    s->capacity = STR_SSO_SIZE;

    if (other->size > 0) {
        ensure_capacity(s, other->size);
        str_copy_n(GET_STR(s), GET_STR(other), other->size);
        s->size = other->size;
    }

    return s;
}

void string_create_stk(String* s, const char* cstr)
{
    CHECK_FATAL(!s, "str is null");

    s->size     = 0;
    s->capacity = STR_SSO_SIZE;

    if (!cstr) {
        return;
    }

    u64 len = cstr_len(cstr);
    if (len == 0) {
        return;
    }

    ensure_capacity(s, len);
    str_copy_n(GET_STR(s), cstr, len);
    s->size = len;
}

void string_destroy(String* s)
{
    CHECK_FATAL(!s, "str is null");
    string_destroy_stk(s);
    free(s);
}

void string_destroy_stk(String* s)
{
    CHECK_FATAL(!s, "str is null");

    if (!IS_SSO(s)) {
        free(s->heap);
        s->heap = NULL;
    }

    s->size     = 0;
    s->capacity = STR_SSO_SIZE; // leave in valid SSO state, not capacity=0
}

void string_move(String* dest, String** src)
{
    CHECK_FATAL(!src, "src ptr is null");
    CHECK_FATAL(!*src, "*src is null");
    CHECK_FATAL(!dest, "dest is null");

    if (dest == *src) {
        *src = NULL;
        return;
    }

    string_destroy_stk(dest);
    memcpy(dest, *src, sizeof(String));

    // Zero out src so its destructor is harmless, then free the struct
    (*src)->size     = 0;
    (*src)->capacity = STR_SSO_SIZE;
    free(*src);
    *src = NULL;
}

void string_copy(String* dest, const String* src)
{
    CHECK_FATAL(!src, "src is null");
    CHECK_FATAL(!dest, "dest is null");

    if (src == dest) {
        return;
    }

    string_destroy_stk(dest);

    dest->size     = 0;
    dest->capacity = STR_SSO_SIZE;

    if (src->size > 0) {
        ensure_capacity(dest, src->size);
        str_copy_n(GET_STR(dest), GET_STR(src), src->size);
        dest->size = src->size;
    }
}


//  Capacity

void string_reserve(String* s, u64 new_cap)
{
    CHECK_FATAL(!s, "str is null");

    if (new_cap <= s->capacity) {
        return;
    }
    ensure_capacity(s, new_cap);
}

void string_reserve_char(String* s, u64 new_cap, char c)
{
    CHECK_FATAL(!s, "str is null");
    if (new_cap <= s->capacity) {
        // Fill from current size up to new_cap within existing allocation.
        char* buf = GET_STR(s);
        for (u64 i = s->size; i < new_cap; i++) {
            buf[i] = c;
        }
        s->size = new_cap;
        return;
    }

    u64 old_size = s->size;
    ensure_capacity(s, new_cap);

    char* buf = GET_STR(s);
    for (u64 i = old_size; i < new_cap; i++) {
        buf[i] = c;
    }
    s->size = new_cap;
}

void string_shrink_to_fit(String* s)
{
    CHECK_FATAL(!s, "str is null");

    if (IS_SSO(s)) {
        return;
    } // already optimal

    if (s->size == 0) {
        free(s->heap);
        s->heap     = NULL;
        s->capacity = STR_SSO_SIZE;
        return;
    }

    if (s->size <= STR_SSO_SIZE) {
        // Bring back to SSO.
        heap_to_stk(s);
        return;
    }

    char* new_data = realloc(s->heap, s->size);
    if (!new_data) {
        WARN("shrink_to_fit realloc failed");
        return;
    }
    s->heap     = new_data;
    s->capacity = s->size;
}


//  Conversion

char* string_to_cstr(const String* s)
{
    CHECK_FATAL(!s, "str is null");

    char* out = malloc(s->size + 1);
    CHECK_FATAL(!out, "malloc failed");

    if (s->size > 0) {
        str_copy_n(out, GET_STR(s), s->size);
    }
    out[s->size] = '\0';

    return out;
}

void string_to_cstr_buf(const String* str, char* buff, u64 n)
{
    CHECK_FATAL(!str, "str is null");
    CHECK_FATAL(!buff, "buff is null");
    CHECK_FATAL(n < str->size + 1, "buffer not enough");

    if (str->size > 0) {
        str_copy_n(buff, GET_STR(str), str->size);
    }
    buff[str->size] = '\0'; 
}

char* string_data_ptr(const String* s)
{
    CHECK_FATAL(!s, "str is null");
    if (s->size == 0) {
        return NULL;
    }
    // Cast away const intentionally: caller may mutate via this pointer.
    return (char*)(IS_SSO(s) ? s->stk : s->heap);
}


//  Modification

void string_append_char(String* s, char c)
{
    CHECK_FATAL(!s, "str is null");
    MAYBE_GROW_STR(s);
    GET_STR_CHAR(s, s->size++) = c;
}

void string_append_cstr(String* s, const char* cstr)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(!cstr, "cstr is null");

    u64 len = cstr_len(cstr);
    if (len == 0) {
        return;
    }

    ensure_capacity(s, s->size + len);
    str_copy_n(GET_STR(s) + s->size, cstr, len);
    s->size += len;
}

void string_append_string(String* s, const String* other)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(!other, "other is null");

    if (other->size == 0) {
        return;
    }

    ensure_capacity(s, s->size + other->size);
    str_copy_n(GET_STR(s) + s->size, GET_STR(other), other->size);
    s->size += other->size;
}

void string_append_string_move(String* s, String** other)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(!other, "other ptr is null");
    CHECK_FATAL(!*other, "*other is null");

    if ((*other)->size > 0) {
        string_append_string(s, *other);
    }

    string_destroy(*other);
    *other = NULL;
}

char string_pop_char(String* s)
{
    CHECK_FATAL(!s, "str is null");
    WC_SET_RET(WC_ERR_EMPTY, s->size == 0, '\0');

    char c = GET_STR_CHAR(s, --s->size);
    return c;
}

void string_insert_char(String* s, u64 i, char c)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(i > s->size, "index out of bounds");

    MAYBE_GROW_STR(s);

    char* buf = GET_STR(s);
    // Shift right.
    for (u64 j = s->size; j > i; j--) {
        buf[j] = buf[j - 1];
    }
    buf[i] = c;
    s->size++;
}

void string_insert_cstr(String* s, u64 i, const char* cstr)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(!cstr, "cstr is null");
    CHECK_FATAL(i > s->size, "index out of bounds");

    u64 len = cstr_len(cstr);
    if (len == 0) {
        return;
    }

    ensure_capacity(s, s->size + len);

    char* buf = GET_STR(s);
    // Shift existing chars right by len positions.
    for (u64 j = s->size; j > i; j--) {
        buf[j + len - 1] = buf[j - 1];
    }
    str_copy_n(buf + i, cstr, len);
    s->size += len;
}

void string_insert_string(String* s, u64 i, const String* other)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(!other, "other is null");
    CHECK_FATAL(i > s->size, "index out of bounds");

    if (other->size == 0) {
        return;
    }

    CHECK_WARN_RET(s == other, , "can't insert aliasing(same) strings");

    u64 len = other->size;
    ensure_capacity(s, s->size + len);

    char* buf = GET_STR(s);
    for (u64 j = s->size; j > i; j--) {
        buf[j + len - 1] = buf[j - 1];
    }
    str_copy_n(buf + i, GET_STR(other), len);
    s->size += len;
}

void string_remove_char(String* s, u64 i)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(i >= s->size, "index out of bounds");

    char* buf = GET_STR(s);
    for (u64 j = i; j < s->size - 1; j++) {
        buf[j] = buf[j + 1];
    }
    s->size--;
}

/*
    0 1 2 3 4 5  (1, 2)
      ^ ^ 
    start = 1
    len = 2
    end = 2

*/

void string_remove_range(String* s, u64 start, u64 len)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(start >= s->size, "start out of bounds");

    if (len == 0) { return; }

    if (start + len >= s->size) {
        len = s->size - start;
    }

    memmove(GET_STR_PTR(s, start), GET_STR_PTR(s, start + len), s->size - len);

    s->size -= len;
}

void string_clear(String* s)
{
    CHECK_FATAL(!s, "str is null");
    s->size = 0;
}


//  Access

char string_char_at(const String* s, u64 i)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(i >= s->size, "index out of bounds");
    return GET_STR_CHAR(s, i);
}

void string_set_char(String* s, u64 i, char c)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(i >= s->size, "index out of bounds");
    *GET_STR_PTR(s, i) = c; // TODO: test this
}


//  Comparison

int string_compare(const String* s1, const String* s2)
{
    CHECK_FATAL(!s1, "str1 is null");
    CHECK_FATAL(!s2, "str2 is null");

    u64 min_len = s1->size < s2->size ? s1->size : s2->size;

    if (min_len > 0) {
        int cmp = memcmp(GET_STR(s1), GET_STR(s2), min_len);
        if (cmp != 0) {
            return cmp;
        }
    }

    if (s1->size < s2->size) {
        return -1;
    }
    if (s1->size > s2->size) {
        return 1;
    }
    return 0;
}

b8 string_equals(const String* s1, const String* s2)
{
    return string_compare(s1, s2) == 0;
}

b8 string_equals_cstr(const String* s, const char* cstr)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(!cstr, "cstr is null");

    u64 len = cstr_len(cstr);

    if (s->size != len) {
        return false;
    }
    if (len == 0) {
        return true;
    }

    return memcmp(GET_STR(s), cstr, len) == 0;
}


//  Search

u64 string_find_char(const String* s, char c)
{
    CHECK_FATAL(!s, "str is null");

    if (s->size == 0) { return (u64)-1; }
    const char* buf = GET_STR(s);
    const char* p   = memchr(buf, (unsigned char)c, s->size);
    return p ? (u64)(p - buf) : (u64)-1;
}

u64 string_find_cstr(const String* s, const char* substr)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(!substr, "substr is null");

    u64 len = cstr_len(substr);
    if (len == 0) {
        return 0;
    }
    if (len > s->size) {
        return (u64)-1;
    }

    const char* buf = GET_STR(s);
    for (u64 i = 0; i <= s->size - len; i++) {
        if (memcmp(buf + i, substr, len) == 0) {
            return i;
        }
    }
    return (u64)-1;
}

String* string_substr(const String* s, u64 start, u64 length)
{
    CHECK_FATAL(!s, "str is null");
    CHECK_FATAL(start >= s->size, "start out of bounds");

    if (start + length > s->size) {
        length = s->size - start;
    }

    String* result = string_create();

    if (length > 0) {
        ensure_capacity(result, length);
        str_copy_n(GET_STR(result), GET_STR(s) + start, length);
        result->size = length;
    }

    return result;
}


//  I/O

void string_print(const String* s)
{
    CHECK_FATAL(!s, "str is null");

    putchar('"');
    const char* buf = GET_STR(s);
    for (u64 i = 0; i < s->size; i++) {
        putchar(buf[i]);
    }
    putchar('"');
}


// TODO: remove this and do ray strlen
static u64 cstr_len(const char* cstr)
{
    return (u64)strlen(cstr);
}

// TODO: remove this and do normal memcpy
static void str_copy_n(char* dest, const char* src, u64 n)
{
    memcpy(dest, src, n);
}

// Promote SSO buffer to heap allocation.
static void stk_to_heap(String* s)
{
    u64 new_cap = (u64)((float)s->capacity * STRING_GROWTH);

    char* new_data = malloc(new_cap);
    CHECK_FATAL(!new_data, "malloc failed");

    str_copy_n(new_data, s->stk, s->size);

    s->heap     = new_data;
    s->capacity = new_cap;
}

static void heap_to_stk(String* s)
{
    char tmp[STR_SSO_SIZE];
    str_copy_n(tmp, s->heap, s->size);
    free(s->heap);
    str_copy_n(s->stk, tmp, s->size);
    s->capacity = STR_SSO_SIZE;
}

static void string_grow(String* s)
{
    u64 new_cap = (u64)((float)s->capacity * STRING_GROWTH);

    char* new_data = realloc(s->heap, new_cap);
    CHECK_FATAL(!new_data, "realloc failed");

    s->heap     = new_data;
    s->capacity = new_cap;
}

static void ensure_capacity(String* s, u64 needed)
{
    if (needed <= s->capacity) {
        return;
    }

    // Grow by at least STRING_GROWTH factor so we don't alloc on every push.
    u64 new_cap = (u64)((float)s->capacity * STRING_GROWTH);
    if (new_cap < needed) {
        new_cap = needed;
    }

    // currently in sso but sso_cap is not enough
    if (IS_SSO(s)) {
        char* new_data = malloc(new_cap);
        CHECK_FATAL(!new_data, "malloc failed");
        str_copy_n(new_data, s->stk, s->size);
        s->heap     = new_data;
        s->capacity = new_cap;
    } else {
        char* new_data = realloc(s->heap, new_cap);
        CHECK_FATAL(!new_data, "realloc failed");
        s->heap     = new_data;
        s->capacity = new_cap;
    }
}

#endif /* WC_STRING_IMPL */

#endif /* WC_IMPLEMENTATION */

#endif /* WC_WC_HELPERS_SINGLE_H */
