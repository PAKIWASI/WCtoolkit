#ifndef COMMON_H
#define COMMON_H



/*
 * WCtoolkit
 * Copyright (c) 2026 Wasi Ullah (PAKIWASI)
 * Licensed under the MIT License. See LICENSE file for details.
 */



// LOGGING/ERRORS

#include <stdalign.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

// ANSI Color Codes
#define WC_COLOR_RESET  "\033[0m"
#define WC_COLOR_RED    "\033[1;31m"
#define WC_COLOR_YELLOW "\033[1;33m"
#define WC_COLOR_GREEN  "\033[1;32m"
#define WC_COLOR_BLUE   "\033[1;34m"
#define WC_COLOR_CYAN   "\033[1;36m"



// TODO: warm paths ?

#define WARN(fmt, ...)                                                  \
    do {                                                                \
        printf(WC_COLOR_YELLOW "[WARN]"                                 \
                               " %s:%d:%s(): " fmt "\n" WC_COLOR_RESET, \
               __FILE__, __LINE__, __func__, ##__VA_ARGS__);            \
    } while (0)

__attribute__((noreturn, format(printf, 4, 5))) static inline void
wc_fatal_report(const char* file, int line, const char* func, const char* fmt, ...)
{
    fprintf(stderr, WC_COLOR_RED "[FATAL] %s:%d:%s(): ", file, line, func);
    va_list args;
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fprintf(stderr, "\n" WC_COLOR_RESET);
    exit(EXIT_FAILURE);
}

#define FATAL(fmt, ...) wc_fatal_report(__FILE__, __LINE__, __func__, fmt, ##__VA_ARGS__)

#define CHECK_WARN(cond, fmt, ...)                           \
    do {                                                     \
        if (__builtin_expect(!!(cond), 0)) {                 \
            WARN("Check: (%s): " fmt, #cond, ##__VA_ARGS__); \
        }                                                    \
    } while (0)

#define CHECK_WARN_RET(cond, ret, fmt, ...)                  \
    do {                                                     \
        if (__builtin_expect(!!(cond), 0)) {                 \
            WARN("Check: (%s): " fmt, #cond, ##__VA_ARGS__); \
            return ret;                                      \
        }                                                    \
    } while (0)

// RULE (D5): FATAL_IF for allocation failure and zero-state (moved-from /
// destroyed) mutation. CHECK_FATAL only for bounds and API misuse: it compiles
// to nothing under NDEBUG, so a CHECK_FATAL on an allocation result means
// Release builds carry on with a NULL pointer.
//
// Unconditional fatal check: stays active under NDEBUG.
#define FATAL_IF(cond, fmt, ...)                              \
    do {                                                      \
        if (__builtin_expect(!!(cond), 0)) {                  \
            FATAL("Check: (%s): " fmt, #cond, ##__VA_ARGS__); \
        }                                                     \
    } while (0)

// Debug-only check for programmer errors (bounds, misuse). See RULE above.
#ifdef NDEBUG
#define CHECK_FATAL(cond, fmt, ...) ((void)0)
#else
#define CHECK_FATAL(cond, fmt, ...)                           \
    do {                                                      \
        if (__builtin_expect(!!(cond), 0)) {                  \
            FATAL("Check: (%s): " fmt, #cond, ##__VA_ARGS__); \
        }                                                     \
    } while (0)
#endif

#define LOG(fmt, ...)                                             \
    do {                                                          \
        printf(WC_COLOR_CYAN "[LOG]"                              \
                             " : %s(): " fmt "\n" WC_COLOR_RESET, \
               __func__, ##__VA_ARGS__);                          \
    } while (0)


// token pasting that expands its arguments first (for __COUNTER__/__LINE__ names)
#define WC_CAT_(a, b) a##b
#define WC_CAT(a, b)  WC_CAT_(a, b)


// TYPES

#include <stdbool.h>
#include <stdint.h>

typedef uint8_t  u8;
typedef uint8_t  b8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

#define WC_NOT_FOUND ((u64) - 1)


// GENERIC FUNCTIONS
#include "wc_allocator.h"

// Deep-copy `src` INTO `dest`, allocating any owned resources from `dst`.
// `dest` is uninitialised raw slot memory (plan 3.3).
typedef void (*wc_copy_fn)(wc_allocator dst, u8* dest, const u8* src);
// Transfer ownership: `dest` takes over everything `src` owned; `src` is left
// ZEROED (safe to destroy, not usable). Containers do memcpy + zero when NULL.
typedef void (*wc_move_fn)(u8* dest, u8* src);
// Release owned resources of the element (not the slot). Elements that own
// memory store their own allocator, so no allocator argument is needed.
typedef void (*wc_delete_fn)(u8* elm);
typedef void (*wc_print_fn)(const u8* elm);
typedef int (*wc_compare_fn)(const void* a, const void* b, u64 size);


// Vtable: one instance shared across all vectors of the same type.
// Pass NULL for any callback not needed.
// For POD types, pass NULL for the whole ops pointer.
typedef struct {
    wc_copy_fn   copy_fn; // Deep copy function for owned resources (or NULL)
    wc_move_fn   move_fn; // Transfer ownership and null original (or NULL)
    wc_delete_fn del_fn;  // Cleanup function for owned resources (or NULL)
} wc_container_ops;


// Heap-box a value-returning constructor through allocator A:
//   GenVec* v = WC_BOX_IN(A, GenVec, GenVec_create, 8, sizeof(int), NULL);
// Invariant: the shell comes from the same allocator the child stores, so a
// by-pointer delete can free the shell with the child's own allocator.
#define WC_BOX_IN(A, T, init_fn, ...)                                      \
    ({                                                                     \
        wc_allocator _wbx_a = (A);                                         \
        T*           _wbx_p = (T*)wc_alloc(_wbx_a, sizeof(T), alignof(T)); \
        FATAL_IF(!_wbx_p, "WC_BOX_IN(" #T "): allocation failed");         \
        *_wbx_p = init_fn(_wbx_a, __VA_ARGS__);                            \
        _wbx_p;                                                            \
    })


// CASTING

#define cast(x)    ((u8*)(&(x)))
#define castptr(x) ((u8*)(x))


// COMMON SIZES

#define KB (1 << 10)
#define MB (1 << 20)

#define nKB(n) ((u64)((n) * KB))
#define nMB(n) ((u64)((n) * MB))


// RAW BYTES TO HEX

static inline void print_hex(const u8* ptr, u64 size, u32 bytes_per_line)
{
    if (ptr == NULL || size == 0 || bytes_per_line == 0) {
        return;
    }

    // hex rep 0-15
    const char* hex = "0123456789ABCDEF";

    for (u64 i = 0; i < size; i++) {
        u8 val1 = ptr[i] >> 4;   // get upper 4 bits as num b/w 0-15
        u8 val2 = ptr[i] & 0x0F; // get lower 4 bits as num b/w 0-15

        printf("%c%c", hex[val1], hex[val2]);

        // Add space or newline appropriately
        if ((i + 1) % bytes_per_line == 0) {
            printf("\n");
        } else if (i < size - 1) {
            printf(" ");
        }
    }

    // Add final newline if we didn't just print one
    if (size % bytes_per_line != 0) {
        printf("\n");
    }
}


// TEST HELPERS

// Generic print functions for primitive types
static inline void wc_print_int(const u8* elm)
{
    printf("%d ", *(int*)elm);
}
static inline void wc_print_u32(const u8* elm)
{
    printf("%u ", *(u32*)elm);
}
static inline void wc_print_u64(const u8* elm)
{
    printf("%llu ", (unsigned long long)*(u64*)elm);
}
static inline void wc_print_float(const u8* elm)
{
    printf("%.2f ", (double)*(float*)elm);
}
static inline void wc_print_char(const u8* elm)
{
    printf("%c ", *(char*)elm);
}
static inline void wc_print_cstr(const u8* elm)
{
    printf("%s ", (const char*)elm);
}


#endif // COMMON_H
